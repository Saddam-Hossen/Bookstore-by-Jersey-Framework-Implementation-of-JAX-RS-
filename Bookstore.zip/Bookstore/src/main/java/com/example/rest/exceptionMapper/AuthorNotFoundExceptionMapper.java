package com.example.rest.exceptionMapper;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

import com.example.rest.exception.AuthorNotFoundException;

@Provider
public class AuthorNotFoundExceptionMapper implements ExceptionMapper<AuthorNotFoundException> {

    @Override
    public Response toResponse(AuthorNotFoundException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Author not found");
        error.put("message", ex.getMessage());

        return Response.status(Response.Status.BAD_REQUEST) // or NOT_FOUND
                       .entity(error)
                       .build();
    }
}
