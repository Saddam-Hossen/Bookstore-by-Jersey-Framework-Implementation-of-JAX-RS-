package com.example.rest.exceptionMapper;

public class CartNotFoundExceptionMapper {

}
