package com.example.rest.exceptionMapper;


import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

import com.example.rest.exception.BookNotFoundException;

@Provider
public class BookNotFoundExceptionMapper implements ExceptionMapper<BookNotFoundException> {

    @Override
    public Response toResponse(BookNotFoundException ex) {
        Map<String, String> error = new HashMap<>();
        error.put("error", "Book not found");
        error.put("message", ex.getMessage());

        return Response.status(Response.Status.BAD_REQUEST)
                       .entity(error)
                       .build();
    }
}
