package com.example.rest.exception;
public class CustomerNotFoundException extends RuntimeException {
    public CustomerNotFoundException(int id) {
        super("Customer with ID " + id + " does not exist.");
    }
}