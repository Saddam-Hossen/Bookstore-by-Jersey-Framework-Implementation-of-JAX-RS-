package com.example.rest;

import org.glassfish.jersey.server.ResourceConfig;
import jakarta.ws.rs.ApplicationPath;
import com.example.rest.resource.*;

@ApplicationPath("/api")
public class AppConfig extends ResourceConfig {
    public AppConfig() {
        packages("com.example.rest.resource","com.example.rest.exception","com.example.rest.exceptionMapper");
    }
}
